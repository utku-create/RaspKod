import speech_recognition
import sounddevice
from google.cloud import speech_v1p1beta1 as speech

# Google Cloud kimlik doğrulama bilgilerini ayarlayın
import os
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/aytar/Desktop/AytarCoding/aytarsestanima1-628f5bb71542.json"

# SpeechRecognition kütüphanesini kullanarak mikrofondan ses alın
recognizer = speech_recognition.Recognizer()

while True:
    try:
        with speech_recognition.Microphone() as mic:
            print("Dinleniyor...")
            recognizer.adjust_for_ambient_noise(mic, duration=0.2)
            audio = recognizer.listen(mic)

            # Google Cloud Speech-to-Text API'yi kullanarak metne dönüştürme
            client = speech.SpeechClient()
            config = speech.RecognitionConfig(
                encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=16000,
                language_code="en-US",
            )
            audio_content = audio.frame_data
            audio = speech.RecognitionAudio(content=audio_content)
            response = client.recognize(config=config, audio=audio)

            for result in response.results:
                print(f"Recognized: {result.alternatives[0].transcript}")

    except speech_recognition.UnknownValueError:
        print("Anlaşılamadı")
        continue
    except KeyboardInterrupt:
        print("Program kapatılıyor")
        break
    
    
    


# import speech_recognition
# import pyttsx3
# import sounddevice
# 
# recognizer = speech_recognition.Recognizer()
# 
# while True:
#     
#     try:
#         
#         with speech_recognition.Microphone() as mic:
#             
#             recognizer.adjust_for_ambient_noise(mic, duration=0.2)
#             audio = recognizer.listen(mic)
#             
#             text = recognizer.recognize_google_cloud(audio)
#             text = text.lower()
#             
#             print(f"Recognized {text}")
#     
#     except speech_recognition.UnknownValueError():
#         recognizer = speech_recognition.Recognizer()
#         continue
#     
#     
#     #------------------------------------- en son kod
# import speech_recognition
# import pyttsx3
# import sounddevice
# 
# # JSON dosyasının yolu
# credentials_path = "/path/to/your/credentials.json"
# 
# recognizer = speech_recognition.Recognizer()
# 
# while True:
#     
#     try:
#         
#         with speech_recognition.Microphone() as mic:
#             
#             recognizer.adjust_for_ambient_noise(mic, duration=0.2)
#             audio = recognizer.listen(mic)
#             
#             # JSON dosyasının yolunu belirterek recognize_google_cloud fonksiyonunu çağırın
#             text = recognizer.recognize_google_cloud(audio, credentials_json=credentials_path)
#             text = text.lower()
#             
#             print(f"Recognized {text}")
#     
#     except speech_recognition.UnknownValueError():
#         recognizer = speech_recognition.Recognizer()
#         continue 

