import playsound
import speech_recognition as sr
from gtts import gTTS
import random
import os
import sounddevice
from pydub import AudioSegment
from pydub.playback import play

def konuş(yazı, dil):
    tts = gTTS(text=yazı, lang=dil)
    dosya_ismi = "ses" + str(random.randint(0, 1000000000000000000000)) + ".mp3"
    tts.save(dosya_ismi)
    playsound.playsound(dosya_ismi)
    os.remove(dosya_ismi)  # Dosyayı çaldıktan sonra sil
    


def sesi_kaydet():
    r = sr.Recognizer()

    with sr.Microphone() as kaynak:
        print("Dinliyorum...")
        ses = r.listen(kaynak)

        söylenen_cümle = ""
        dil = "tr"  # Varsayılan dil Türkçe

        try:
            söylenen_cümle = r.recognize_google(ses, language="tr-TR,en-US")
            print("Söylenen cümle:", söylenen_cümle)

            if any(ord(char) > 128 for char in söylenen_cümle):  # İngilizce karakter kontrolü
                dil = "en"

        except sr.UnknownValueError:
            konuş("Ne dediğinizi anlayamadım, lütfen tekrar edin.", "tr")
        except sr.RequestError:
            konuş("Üzgünüm, servisle ilgili bir problem var.", "tr")
        except Exception as e:
            konuş("Bir hata oluştu: " + str(e), "tr")

    return söylenen_cümle, dil


while True:
    yazı, dil = sesi_kaydet()

    if "nasılsın" in yazı.lower():
        konuş("İyiyim, sen nasılsın?", "tr")
    elif "benim adım ne" in yazı.lower():
        konuş("Adınız Buğra, efendim.", "tr")
    elif "how are you" in yazı.lower():
        konuş("I'm fine, how are you?", "en")
    elif "what is my name" in yazı.lower():
        konuş("Your name is Buğra, sir.", "en")
    elif "çıkış" in yazı.lower() or "exit" in yazı.lower():
        if dil == "tr":
            konuş("Görüşmek üzere!", "tr")
        else:
            konuş("See you later!", "en")
        break