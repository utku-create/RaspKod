import json
import sounddevice
import speech_recognition as sr

# JSON içeriği
google_cloud_speech_credentials = {
    "type": "service_account",
    "project_id": "aytarsestanima1",
    "private_key_id": "42be531949a06bd6c2c540509cf753de9f910e7d",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCmvG1MDuI3iCt3\nbsr4zn0zfpF9sfI4taSjrJIilMY4EsZ6xYJxb7pnOHE24qCujH1rtr18eJyP3dbE\n9Fz8UNwY9OrHB30R4HDIMaSDw/usjY4mSYqir7U9CQvo+g3GpN0QALmCJEpoWf6K\nLaOHf6WeGUAjya0wGdUh6RNMYmCZ9fv00a2YHmvRn108qh+cLpGYm/+kZ84F7Rs4\nFSqoslPCO2mAg3swZ9Rm3haJuehZ/cMwAVUKt4OxHHdRWgHD6NmxEDXEHby7tO9R\nUgzd7OUazQUB6gRxx9p0qhyACar+UEaCqacKXnvytYNuVSis7hltxe2BCoiMldqk\nR9t7SbQbAgMBAAECggEAEUF19EWkDsg2a2VZdzdziKVELGSCo3DVCaVd+Fs6SmpT\nBTi0n8XG3lDekqYQqA/dGQ0v/hZDabY1OGvrxaceqCyMsa1qObPnKCjPFF3viXOa\n7wZ0ZRLXKGprw6BBVboRMMtKZ5gW5UbPC4DeqDLDMqH9W9bO6Cf8QUasWx7hTX2X\nQ8qNkCrjnqmkto7ktgyFTVMo/DQ9a7DG2nBexNYRmLz83pQfd8S7pZzb5P8f3ftl\nuw18ewSmOz9wQD7/aV0yIYwwB67YR9/tw4yw0hi6BIs/0keNYu193PPgDbCzbsX/\n5R7BEkCmRT7IoSsKWkszeXgJVxqinvrCo6zcLm5gQQKBgQDevpeLx6beRRqgXMy/\nRUjgRN/p0ubRn6tHZ47ynFL51SM0ytIpa54x0MwM6oSmjGPrEteh9I9blDphVwAV\n+PodTzWBs8nvGxfxMLo0UGlUsJgMZGcPjT8LvEvaPSEIKk5u4lbj33GlqHZPpjn4\nLp8wpQ+MdcNlyNbU1g2ZrLtyQQKBgQC/oSnLWlktR8bBz7TKiO/yI8NlWbunkm3k\nYEiTJ6+/usJtm0p2+D6INXbGzR+Fgx8mDryF8b9oOagcXl0uE6SH7XBugZCNyy5I\noprQUE9XOOJRAtcyBSs6ieCSB//TQUKkiPQ5jVW1XLh6pfD4xTVr/synxXiNpuBY\nqBF2A9RXWwKBgQDG6nGvlGZCjHfQyc7W6OrBzQAhcgRLI0n0BFk188Bt95bvKEky\nUDb/ybTPvAcmLK12WmdS7HGxmNfh4a3j8Wp7Did8YrBs5UcmTxuaaE0IIoRGXMtk\nqgCpXEho5ro+7nkIsPxjl0GIbL7rNkkCh7AF4wHVr70FgqvHeji/CfCDgQKBgFxm\nqNF+WjvEPWmc7u8uQoz+g6xuLVcq+0RAzR3v6AXKVxAk7i4Zm4VwSjqoFAf75twi\nBPONUx89lfs/4SxjmlVUv375iKtmioXJql7CKs/DBRXNCdj7txF+BERGCSxjbnAJ\n/cF2jhpqgCXbuCssZIsTjLllNbEQA2Ocfvbp98y7AoGAJYqO+Rdk7hn4jvbOxK1x\nkbQRAvxRGDSZN83IQ07WELC6RL0xfVDTS5O9QH2gHSHF6p+HefghlxnnFbXhNiMI\nCGOKgOB8RbkgjaZYZcidDLWV9rCi1U9H5Kmw3GxOV9ZuZ1RIiq4XLcma1qkwJOkR\nW1yv/wLYhxUfmuOSGE3gD3k=\n-----END PRIVATE KEY-----\n",
    "client_email": "aytarsesservisi@aytarsestanima1.iam.gserviceaccount.com",
    "client_id": "103241478919682237988",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/aytarsesservisi@aytarsestanima1.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
}

# JSON içeriğini bir string olarak saklayın
credentials_json = json.dumps(google_cloud_speech_credentials)

rec = sr.Recognizer()

with sr.Microphone() as mic:
    rec.adjust_for_ambient_noise(mic)
    print("Dinliyorum seni")
    audio = rec.listen(mic)
    
    try:
        # JSON stringini kullanarak Google Cloud Speech-to-Text API'sini çağırın
        print("Bunu dedin: " + rec.recognize_google_cloud(audio, credentials_json=credentials_json))
    except sr.UnknownValueError:
        print("Google Speech Recognition API anlamadı")
    except sr.RequestError as e:
        print("Google Speech Recognition hizmetinden sonuç istenemedi; {0}".format(e))
